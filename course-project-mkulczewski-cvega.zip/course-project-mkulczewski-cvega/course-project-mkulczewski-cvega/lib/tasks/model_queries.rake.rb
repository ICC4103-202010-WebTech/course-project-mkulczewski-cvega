namespace :db do
  task :model_queries => :environment do

    #Cada query tiene asignado un id de ejemplo, pero puede cambiarse para probar con otros.

    puts("Query 1: Get all events created by certain user.")
    result = Event.select(:name).joins(:event_creator).where("user_id = '4'")
    puts(result)
    puts("EOQ")

    puts("Query 2: Get all users belonging to an organization. ")
    result = User.select(:user_name).joins(:organization_members).where("organization_id = '1'")
    puts(result)
    puts("EOQ")

    puts("Query 3: Get all public events in an organization. ")
    result = Organization.find(1).events.where(public: true)
    puts(result)
    puts("EOQ")

    puts("Query 4: Get all private events in an organization. ")
    result =  Organization.find(1).events.where(public: false)
    puts(result)
    puts("EOQ")

    puts("Query 5: Get all guests that have been invited to a certain event.")
    result = Event.find(1).users
    puts(result)
    puts("EOQ")

    puts("Query 6: Get all guests that have voted for a date option in a certain event. ")
    result = Event.find(1).invitations.where("vote NOT NULL")
    puts(result)
    puts("EOQ")

    puts("Query 7: Get all comments written by users on a specific event. ")
    result =  Event.find(3).comments
    puts(result)
    puts("EOQ")

    puts("Query 8: Get all comments written by a specific user on all events. ")
    result = User.find(1).comments
    puts(result)
    puts("EOQ")

    puts("Query 9: Get all users with administrative privileges in an organization. ")
    result = Organization.find(2).organization_members.where(admin: true).distinct.map { |x| x.user }
    puts(result)
    puts("EOQ")

    puts("Query 10: Get all users with administrative privileges in the system.")
    result = User.where(system_admin: true)
    puts(result)
    puts("EOQ")

  end
end






