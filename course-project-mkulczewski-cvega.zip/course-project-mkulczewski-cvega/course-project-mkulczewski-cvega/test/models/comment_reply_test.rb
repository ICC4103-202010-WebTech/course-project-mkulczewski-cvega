require 'test_helper'

class CommentReplyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
