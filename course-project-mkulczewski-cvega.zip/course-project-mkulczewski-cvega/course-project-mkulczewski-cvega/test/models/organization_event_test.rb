require 'test_helper'

class OrganizationEventTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
