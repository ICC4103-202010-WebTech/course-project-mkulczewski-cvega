require 'test_helper'

class OrganizationMemberTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
