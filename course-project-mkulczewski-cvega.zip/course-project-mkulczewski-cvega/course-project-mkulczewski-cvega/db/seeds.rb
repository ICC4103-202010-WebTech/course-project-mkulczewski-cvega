# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

u1 = User.create(name: "mati", last_name: "vega", user_name: "mati1", mail: "mati1@gmail.com", system_admin: true)
u2 = User.create(name: "carlos", last_name: "vega", user_name: "carlos1", mail: "carlos1@gmail.com", system_admin: false)
u3 = User.create(name: "juan", last_name: "vega", user_name: "juan1", mail: "juan1@gmail.com", system_admin: false)
u4 = User.create(name: "martin", last_name: "vega", user_name: "martin1", mail: "martin1@gmail.com", system_admin: false)
u5 = User.create(name: "benja", last_name: "vega", user_name: "benjazard", mail: "benjazard@gmail.com", system_admin: false)


o1 = Organization.create(name: "blabla")
o2 = Organization.create(name: "Rito")

e1 = Event.create(name: "pesca", date_event: "2020-04-19 16:27:50", public: true, description: "evento muy weno")
e2 = Event.create(name: "smash ", date_event: "2020-05-19 16:27:50", public: true, description: "evento muy weno 1")
e3 = Event.create(name: "No Items, Fox only, Final Destination", date_event: "2020-05-20 16:27:50", public: false, description: "evento muy weno 2")


i1 = Invitation.create(vote: "2020-04-19 16:27:50", user: u1, event: e1)
i2 = Invitation.create(vote: "2020-05-19 16:27:50", user: u1, event: e2)
i3 = Invitation.create(vote: "2020-05-20 16:27:50", user: u1, event: e3)
i4 = Invitation.create(vote: "2020-04-19 16:27:50", user: u2, event: e1)
i5 = Invitation.create(vote: "2020-05-20 16:27:50", user: u2, event: e3)
i6 = Invitation.create(vote: "2020-05-19 16:27:50", user: u3, event: e2)
i7 = Invitation.create(vote: "2020-05-20 16:27:50", user: u3, event: e3)
i8 = Invitation.create(vote: "2020-04-19 16:27:50", user: u4, event: e1)
i9 = Invitation.create(vote: "2020-05-19 16:27:50", user: u4, event: e2)
i10 = Invitation.create(vote: "2020-05-20 16:27:50", user: u5, event: e3)

om1 = OrganizationMember.create(user: u1, organization: o1, admin: true)
om2 = OrganizationMember.create(user: u2, organization: o1, admin: false)
om3 = OrganizationMember.create(user: u3, organization: o1, admin: false)
om4 = OrganizationMember.create(user: u4, organization: o2, admin: false)
om5 = OrganizationMember.create(user: u5, organization: o2, admin: true)

oe1 = OrganizationEvent.create(event: e1, organization: o1)
oe2 = OrganizationEvent.create(event: e2, organization: o1)
oe3 = OrganizationEvent.create(event: e3, organization: o2)

ec1 = EventCreator.create(user: u3, event: e1)
ec2 = EventCreator.create(user: u2, event: e2)
ec3 = EventCreator.create(user: u4, event: e3)

c1 = Comment.create(text: "se me perdio mi celular x si alguien lo ve", user: u2, event: e1)
c2 = Comment.create(text: "llego tarde", user: u1, event: e2)
c3 = Comment.create(text: "gracias por venir", user: u3, event: e1)
c4 = Comment.create(text: "hay un auto con las luces prendidas", user: u5, event: e3)

r1 = CommentReply.create(reply: "lo encontre", user: u3, comment: c1)
r2 = CommentReply.create(reply: "se paso bien", user: u1, comment: c3)

