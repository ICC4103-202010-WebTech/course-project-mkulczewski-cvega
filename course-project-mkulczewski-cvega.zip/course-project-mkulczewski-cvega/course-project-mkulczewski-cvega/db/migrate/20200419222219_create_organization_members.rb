class CreateOrganizationMembers < ActiveRecord::Migration[6.0]
  def change
    create_table :organization_members do |t|
      t.boolean :admin

      t.timestamps
    end
  end
end
