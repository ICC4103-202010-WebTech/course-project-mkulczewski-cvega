class Event < ApplicationRecord
  has_one :event_creator
  has_many :invitations
  has_many :users, through: :invitations
  has_many :organization_events
  has_many :comments
end
