
class MailValidator < ActiveModel::EachValidator
  def validate_each(record, attribute, value)
    unless value =~ /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\z/i
      record.errors[attribute] << (options[:message] || "is not an email")
    end
  end
end

class User < ApplicationRecord
  validates :mail, presence: true, uniqueness: true, mail: true
  validates :user_name, uniqueness: true
  has_many :invitations
  has_many :events, through: :invitations
  has_one :event_creator
  has_many :organization_members
  has_many :organizations, through: :organization_members
  has_many :comments
  has_many :comment_replies
end
